/* for w32 */

#define GOLD_write_t	GOLD_write_b
#define GOLD_exit		ExitProcess
